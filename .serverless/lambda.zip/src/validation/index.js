const {
	login
} = require("./hrmodulevalidation");

module.exports = {
	login
};